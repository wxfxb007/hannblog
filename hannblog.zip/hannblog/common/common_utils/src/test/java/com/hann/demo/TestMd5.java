package com.hann.demo;

import com.hann.commonutils.MD5;

public class TestMd5 {
    public static void main(String[] args) {
        System.out.println(MD5.encrypt("111111"));
    }
}
