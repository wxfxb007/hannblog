package com.hann.servicebase.Exception;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor //生成有参构造的方法
@NoArgsConstructor //生成无参构造的方法

public class HannException extends RuntimeException{

    private Integer code;//状态码
    private String msg; //异常信息

}
