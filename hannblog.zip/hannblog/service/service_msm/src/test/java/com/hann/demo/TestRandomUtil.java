package com.hann.demo;

public class TestRandomUtil {
    public static void main(String[] args) {
        System.out.println(RandomUtil.getFourBitRandom());
    }
}
