package com.hann.controller;

import com.hann.commonutils.R;
import com.hann.service.MsmService;
import com.hann.utils.RandomUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

@RestController
@CrossOrigin
@RequestMapping("/blogmsm/msm")
@Slf4j
public class MsmController {

    @Autowired
    private MsmService msmService;

    @Autowired
    private RedisTemplate<String,String> redisTemplate;

    //发送短信息的方法
    @GetMapping("send/{phone}")
    public R sendMsm (@PathVariable("phone") String phone){
        //从redis获取验证码，如果获取到则直接返回
        String code = redisTemplate.opsForValue().get(phone);
        if (!StringUtils.isEmpty(code)){
            log.info("已有的code:",code);
            return R.ok().data("code",code);
        }


        //生成一个随即的值，传递给阿里云再发送
        code = RandomUtil.getFourBitRandom();
        Map<String,Object> param = new HashMap<>();
        param.put("code",code);
        //调用service中发送短信的方法
        boolean isSend =  msmService.send(param,phone);
        log.info("生成的code1"+code);
        if (isSend){
            //发送成功后，将验证发放入到redis 里面
            //设置有效时间
            redisTemplate.opsForValue().set(phone,param.get("code").toString(),5, TimeUnit.MINUTES);
            log.info("生成的code"+code);

            return R.ok().data("code",code);
        }else {
            return R.error().message("短信发送失败");
        }

    }
}
