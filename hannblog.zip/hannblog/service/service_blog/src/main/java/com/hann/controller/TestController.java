package com.hann.controller;

import com.hann.commonutils.R;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/test")
public class TestController {
    @GetMapping("/ss")
    public R ss(){
        return R.ok().data("success","三生三世");
    }
}
