package com.hann.demo.excel;

import com.alibaba.excel.EasyExcel;

import java.util.ArrayList;
import java.util.List;

public class TestEasyExcel {

    public static void main(String[] args) {
        //实现excel 的写操作
        //1设置写入文件夹地址和excel 的文件名陈
        String filename = "G:\\write.xlsx";
        //调用exsyexcel里面的方法实现写操作
        //第一个参数是文件路径名称，第二个参数是实体类的名称
        EasyExcel.write(filename,DemoData.class).sheet("学生列表").doWrite(getData());

    }

    private static List<DemoData> getData (){
        List<DemoData> list = new ArrayList<>();
        for (int i= 0;i<10;i++){
            DemoData data = new DemoData();
            data.setName("lucy"+i);
            data.setSno(i);
            list.add(data);
        }
        return list;
    }
}
