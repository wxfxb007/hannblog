package com.hann.demo.excel;

import com.alibaba.excel.EasyExcel;

public class TestEasyExcelRead {


    public static void main(String[] args) {

        String filename = "G:\\write.xlsx";

        EasyExcel.read(filename,DemoData.class,new ExcelListener()).sheet().doRead();


    }
}
