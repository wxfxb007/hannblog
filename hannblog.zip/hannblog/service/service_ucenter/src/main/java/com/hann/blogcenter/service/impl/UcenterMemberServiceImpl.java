package com.hann.blogcenter.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.hann.blogcenter.entity.UcenterMember;
import com.hann.blogcenter.entity.vo.RegisterVo;
import com.hann.blogcenter.mapper.UcenterMemberMapper;
import com.hann.blogcenter.service.UcenterMemberService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.hann.commonutils.JwtUtils;
import com.hann.commonutils.MD5;
import com.hann.servicebase.Exception.HannException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import javax.management.Query;

/**
 * <p>
 * 会员表 服务实现类
 * </p>
 *
 * @author fxb
 * @since 2020-10-06
 */
@Service
@Slf4j
public class UcenterMemberServiceImpl extends ServiceImpl<UcenterMemberMapper, UcenterMember> implements UcenterMemberService {

    @Autowired
    private RedisTemplate<String,String> redisTemplate;
    @Override
    public String login(UcenterMember member) {
        //获取登录手机号
        String mobile = member.getMobile();
        String password = member.getPassword();

        if (StringUtils.isEmpty(mobile) || StringUtils.isEmpty(password)){
            throw new HannException(20001,"登录失败");
        }
        QueryWrapper<UcenterMember> wrapper = new QueryWrapper<>();
        wrapper.eq("mobile",mobile);

        UcenterMember mobileMember = baseMapper.selectOne(wrapper);
        if (mobileMember == null){
            throw new HannException(20001,"登录失败");
        }
        if (!MD5.encrypt(password).equals(mobileMember.getPassword())){
            throw new HannException(20001,"登录失败");
        }
        if (mobileMember.getIsDisabled()){
            throw new HannException(20001,"登录失败");
        }
        //登录成功后，按照规则生成字符串
        String token = JwtUtils.getJwtToken(mobileMember.getId(),mobileMember.getNickname());
        return token;
    }

    //注册方法
    @Override
    public void register(RegisterVo registerVo) {
        //获取注册数据
        String code = registerVo.getCode();
        String mobile = registerVo.getMobile();
        String nickname = registerVo.getNickname();
        String password = registerVo.getPassword();

        //判断非空
        if (StringUtils.isEmpty(mobile) || StringUtils.isEmpty(password) ||
                StringUtils.isEmpty(code) || StringUtils.isEmpty(nickname)){
            throw new HannException(20001,"注册失败");
        }
        //判断验证码
        String redisCode = redisTemplate.opsForValue().get(mobile);
        System.out.println("redisCode:"+redisCode);
        System.out.println("code:"+code);
        log.info("注册时，从redis中取出的code:",redisCode);
        if (!code.equals(redisCode)){
            throw new HannException(20001,"注册失败");
        }

        //判断手机号是否重复
        QueryWrapper<UcenterMember> wrapper = new QueryWrapper<>();
        wrapper.eq("mobile",mobile);
        int count = baseMapper.selectCount(wrapper);
        if (count>0){
            throw new HannException(20001,"注册失败");
        }
        UcenterMember ucenterMember = new UcenterMember();
        ucenterMember.setMobile(mobile);
        ucenterMember.setNickname(nickname);
        ucenterMember.setPassword(MD5.encrypt(password));
        ucenterMember.setIsDisabled(false);
        ucenterMember.setAvatar("http://thirdwx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTJ9CsqApybcs7f3Dyib9IxIh0sBqJb7LicbjU4WticJFF0PVwFvHgtbFdBwfmk3H2t3NyqmEmVx17tRA/132");
        baseMapper.insert(ucenterMember);
    }
}
