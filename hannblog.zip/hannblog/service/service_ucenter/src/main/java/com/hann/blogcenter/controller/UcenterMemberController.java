package com.hann.blogcenter.controller;


import com.hann.blogcenter.entity.UcenterMember;
import com.hann.blogcenter.entity.vo.RegisterVo;
import com.hann.blogcenter.service.UcenterMemberService;
import com.hann.commonutils.JwtUtils;
import com.hann.commonutils.R;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;

/**
 * <p>
 * 会员表 前端控制器
 * </p>
 *
 * @author fxb
 * @since 2020-10-06
 */
@RestController
@CrossOrigin
@RequestMapping("/blogcenter/member")
public class UcenterMemberController {

    @Autowired
    private UcenterMemberService ucenterMemberService;


    //登录
   @PostMapping("/login")
    public R loginUser (@RequestBody UcenterMember member){
       //调用service方法登录
       //返回token值,使用jwt生成
       String token = ucenterMemberService.login(member);

       return R.ok().data("token",token);
   }
    //注册

    @PostMapping("/register")
    public R registerUser (@RequestBody RegisterVo registerVo){

       ucenterMemberService.register(registerVo);
       return R.ok();
    }

    //根据token 获取用户信息
    @GetMapping("/getMemberInfo")
    public R getMemberInfo (HttpServletRequest request){
        String memberId = JwtUtils.getMemberIdByJwtToken(request);
        //调用数据库的方法查询用信息
       UcenterMember userInfo = ucenterMemberService.getById(memberId);
       return R.ok().data("userInfo",userInfo);
    }
}

